# main.py
import telebot
from config import BOT_TOKEN, ADMIN_IDS
from handlers import start_handler, message_router
from keyboards.admin_kb import get_admin_keyboard
from admin_control.db_manager import init_databases
from user_system.db_user_codes import init_user_db
from trial_system.db_manager import init_trial_db

bot = telebot.TeleBot(BOT_TOKEN)

# تسجيل المعالجات
start_handler.register(bot)
message_router.register(bot)

def notify_admins_on_startup():
    """إرسال رسالة ترحيب تلقائية لكل مشرف عند تشغيل البوت."""
    welcome_msg = "✅ تم تشغيل البوت بنجاح!\nمرحباً يا مشرف 🛡️\nلوحة التحكم جاهزة لك:"
    for admin_id in ADMIN_IDS:
        try:
            bot.send_message(admin_id, welcome_msg, reply_markup=get_admin_keyboard())
            print(f"[+] رسالة ترحيب أُرسلت إلى المشرف: {admin_id}")
        except Exception as e:
            print(f"[-] فشل إرسال رسالة إلى {admin_id}: {e}")

if __name__ == "__main__":
    print("🚀 جاري تشغيل البوت...")
    init_trial_db()
    init_databases()
    init_user_db()
    notify_admins_on_startup()  # ← الإرسال التلقائي هنا
    bot.infinity_polling()