# features/code_activation.py
from user_system.user_status import get_code_type, is_code_valid, is_code_already_used, mark_code_as_used
from user_system.db_user_codes import save_user_code, remove_user_code

def handle_code_activation(bot, message, is_new_code=False):
    user_id = message.from_user.id
    chat_id = message.chat.id
    code = message.text.strip()

    code_type = get_code_type(code)
    if not code_type:
        bot.send_message(chat_id, "❌ تنسيق الكود غير صحيح.")
        return

    if is_code_already_used(code, code_type):
        bot.send_message(chat_id, "❌ هذا الكود تم استخدامه مسبقًا.")
        return

    if not is_code_valid(code, code_type):
        bot.send_message(chat_id, "❌ الكود غير صالح أو منتهي الصلاحية.")
        return

    if not mark_code_as_used(code, code_type, user_id):
        bot.send_message(chat_id, "❌ حدث خطأ أثناء ربط الكود.")
        return

    save_user_code(user_id, code, code_type)
    
    if code_type == "normal":
        from keyboards.normal_user_kb import get_normal_user_keyboard
        bot.send_message(chat_id, "✅ تم تفعيل كود عادي بنجاح!", reply_markup=get_normal_user_keyboard())
    else:
        from keyboards.vip_user_kb import get_vip_user_keyboard
        bot.send_message(chat_id, "💎 تم تفعيل كود VIP بنجاح!", reply_markup=get_vip_user_keyboard())