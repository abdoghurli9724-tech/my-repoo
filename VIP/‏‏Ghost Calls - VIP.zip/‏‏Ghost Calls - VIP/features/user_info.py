# features/user_info.py
def send_bot_info(bot, chat_id):
    """
    إرسال رسالة معلومات مخصصة للمستخدم العادي.
    """
    info_message = (
        "👋 *مرحباً بك في بوت CoderStorm!*\n\n"
        "🛡️ هذا البوت مصمم لتقديم أدوات ذكية وآمنة عبر واجهة تيليجرام سهلة الاستخدام.\n\n"
        "✨ *الميزات المتاحة لك كمستخدم عادي:*\n"
        "• عرض معلومات البوت\n"
        "• طلب دعم فني\n"
        "• التواصل المباشر مع المطور\n\n"
        "🔒 *ملاحظة مهمة:*\n"
        "بعض الميزات المتقدمة (مثل أدوات الإرسال التلقائي) متاحة فقط للمشرفين المصرّح لهم.\n\n"
        "👨‍💻 *للتواصل:* [@CoderStormVip](https://t.me/@CoderStormVip)\n"
        "💡 البوت تحت التطوير المستمر لإضافة ميزات جديدة!"
    )
    bot.send_message(chat_id, info_message, parse_mode="Markdown", disable_web_page_preview=True)