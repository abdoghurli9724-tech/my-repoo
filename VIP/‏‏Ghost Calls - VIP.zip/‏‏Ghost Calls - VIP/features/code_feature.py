# features/code_feature.py
def send_bot_info(bot, chat_id):
    bot.send_message(chat_id, "استخدم زر CODE لإدخال كود التفعيل.")

def handle_code_feature(bot, chat_id):
    bot.send_message(chat_id, "🔑 أدخل كود التفعيل الخاص بك:")
    bot.register_next_step_handler_by_chat_id(chat_id, lambda msg: _process_code(msg, bot))

def _process_code(message, bot):
    from features.code_activation import handle_code_activation
    handle_code_activation(bot, message, is_new_code=False)