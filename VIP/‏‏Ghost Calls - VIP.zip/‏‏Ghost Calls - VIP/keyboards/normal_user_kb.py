# keyboards/normal_user_kb.py
from telebot.types import ReplyKeyboardMarkup, KeyboardButton

def get_normal_user_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("📞 سبام مكالمات (عادي)"))
    markup.row(KeyboardButton("NEW CODE"), KeyboardButton("👨‍💻 المطور"))
    return markup

def get_country_keyboard_normal():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("العراق 🇮🇶"))
    markup.row(KeyboardButton("سوريا 🇸🇾"))
    markup.row(KeyboardButton("مصر 🇪🇬"))
    return markup