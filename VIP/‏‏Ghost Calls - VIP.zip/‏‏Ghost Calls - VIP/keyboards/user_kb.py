# keyboards/user_kb.py
from telebot.types import ReplyKeyboardMarkup, KeyboardButton

def get_user_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(
        KeyboardButton("ℹ️ معلومات البوت"),
        KeyboardButton("👨‍💻 المطور")
    )
    markup.row(
        KeyboardButton("CODE")
    )
    return markup