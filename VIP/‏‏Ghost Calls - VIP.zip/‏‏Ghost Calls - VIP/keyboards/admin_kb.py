# keyboards/admin_kb.py
from telebot.types import ReplyKeyboardMarkup, KeyboardButton

def get_admin_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("📞 تشغيل سبام المكالمات"))
    markup.row(KeyboardButton("⚙️ لوحة التحكم"))
    return markup
pass

def get_country_keyboard_admin():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("العراق 🇮🇶"))
    markup.row(KeyboardButton("سوريا 🇸🇾"))
    markup.row(KeyboardButton("مصر 🇪🇬"))
    markup.row(KeyboardButton("🔙 إلغاء"))
    return markup


