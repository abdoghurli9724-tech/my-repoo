# keyboards/trial_user_kb.py
from telebot.types import ReplyKeyboardMarkup, KeyboardButton

def get_trial_user_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("📞 سبام مكالمات (تجريبي)"))
    markup.row(KeyboardButton("ℹ️ معلومات التجربة"))
    markup.row(KeyboardButton("👨‍💻 المطور"))
    return markup