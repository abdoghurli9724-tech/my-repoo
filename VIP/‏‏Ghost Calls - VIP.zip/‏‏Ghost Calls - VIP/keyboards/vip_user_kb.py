# keyboards/vip_user_kb.py
from telebot.types import ReplyKeyboardMarkup, KeyboardButton

def get_vip_user_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("📞 سبام مكالمات (VIP)"))
    markup.row(KeyboardButton("NEW CODE"), KeyboardButton("👨‍💻 المطور"))
    return markup

def get_country_keyboard_vip():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("العراق 🇮🇶"))
    markup.row(KeyboardButton("سوريا 🇸🇾"))
    markup.row(KeyboardButton("مصر 🇪🇬"))
    return markup