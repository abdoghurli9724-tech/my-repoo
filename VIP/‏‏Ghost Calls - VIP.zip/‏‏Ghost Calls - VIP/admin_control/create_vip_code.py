# admin_control/create_vip_code.py
import random
import string
from admin_control.db_manager import save_vip_code

def generate_vip_code():
    chars = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
    return f"@CoderStormVip{chars}"

def handle_vip_code(bot, chat_id, admin_id):
    code = generate_vip_code()
    bot.send_message(chat_id, f"🌟 الكود VIP: `{code}`\n\n⏳ أدخل **عدد الأيام** لصلاحية الكود:", parse_mode="Markdown")
    bot.register_next_step_handler_by_chat_id(chat_id, lambda msg: _ask_hours_vip(msg, bot, code, admin_id))

def _ask_hours_vip(message, bot, code, admin_id):
    try:
        days = int(message.text.strip())
        if days < 0:
            raise ValueError
        bot.send_message(message.chat.id, "⏰ أدخل **عدد الساعات**:")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _ask_minutes_vip(msg, bot, code, days, admin_id))
    except:
        bot.send_message(message.chat.id, "❌ أدخل عددًا صحيحًا للأيام:")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _ask_hours_vip(msg, bot, code, admin_id))

def _ask_minutes_vip(message, bot, code, days, admin_id):
    try:
        hours = int(message.text.strip())
        if hours < 0 or hours > 23:
            raise ValueError
        bot.send_message(message.chat.id, "⏱️ أدخل **عدد الدقائق**:")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _save_vip_code(msg, bot, code, days, hours, admin_id))
    except:
        bot.send_message(message.chat.id, "❌ أدخل عددًا صحيحًا للساعات (0-23):")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _ask_minutes_vip(msg, bot, code, days, admin_id))

def _save_vip_code(message, bot, code, days, hours, admin_id):
    try:
        minutes = int(message.text.strip())
        if minutes < 0 or minutes > 59:
            raise ValueError
        save_vip_code(code, days, hours, minutes, admin_id)
        total = f"{days} يوم، {hours} ساعة، {minutes} دقيقة"
        bot.send_message(message.chat.id, f"💎 تم حفظ كود VIP بنجاح!\n\nالكود: `{code}`\nالمدة: {total}", parse_mode="Markdown")
    except:
        bot.send_message(message.chat.id, "❌ أدخل عددًا صحيحًا للدقائق (0-59):")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _save_vip_code(msg, bot, code, days, hours, admin_id))