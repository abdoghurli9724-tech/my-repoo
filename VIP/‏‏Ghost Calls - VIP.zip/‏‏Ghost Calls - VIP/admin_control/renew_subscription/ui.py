# admin_control/renew_subscription/ui.py
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
from datetime import datetime

def show_user_selection(bot, chat_id):
    from .user_fetcher import get_all_active_users
    users = get_all_active_users()
    
    if not users:
        bot.send_message(chat_id, "❌ لا يوجد مستخدمين مفعلين حاليًّا.")
        return

    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    for user_id, code, code_type, expires_at in users:
        try:
            expires_dt = datetime.fromisoformat(expires_at)
            remaining = expires_dt - datetime.now()
            days_left = max(0, remaining.days)
            label = f"🆔 {user_id} | {code_type.upper()} | {days_left} يوم"
        except:
            label = f"🆔 {user_id} | {code_type.upper()} | ???"
        markup.row(KeyboardButton(label))
    
    markup.row(KeyboardButton("🔙 إلغاء"))
    bot.send_message(chat_id, "اختر المستخدم الذي تريد تجديد اشتراكه:", reply_markup=markup)

def show_renewal_options(bot, chat_id, user_id, code_type, current_expires):
    from datetime import datetime
    try:
        expires_dt = datetime.fromisoformat(current_expires)
        remaining = expires_dt - datetime.now()
        days_left = max(0, remaining.days)
        status = f"الكود ساري. المتبقي: {days_left} يوم"
    except:
        status = "الكود منتهي أو غير صالح"
    
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("+1 يوم"))
    markup.row(KeyboardButton("+7 أيام"))
    markup.row(KeyboardButton("+30 يومًا"))
    markup.row(KeyboardButton("تحديد وقت مخصص"))
    markup.row(KeyboardButton("🔙 إلغاء"))
    
    bot.send_message(chat_id, f"🔄 تجديد اشتراك للمستخدم: {user_id}\nالنوع: {code_type.upper()}\nالحالة: {status}\n\nاختر مدة التجديد:", reply_markup=markup)