# admin_control/renew_subscription/user_fetcher.py
import sqlite3

def get_all_active_users():
    """
    جلب جميع المستخدمين الذين لديهم كود مفعل (عادي أو VIP).
    يُرجع قائمة بـ (user_id, code, code_type, expires_at)
    """
    users = []
    try:
        # جلب من قاعدة NORMAL
        conn = sqlite3.connect('NORMAL_CODE_LOG.db')
        c = conn.cursor()
        c.execute("SELECT used_by, code, 'normal', expires_at FROM codes WHERE used_by IS NOT NULL")
        users.extend(c.fetchall())
        conn.close()

        # جلب من قاعدة VIP
        conn = sqlite3.connect('VIP_CODE_LOG.db')
        c = conn.cursor()
        c.execute("SELECT used_by, code, 'vip', expires_at FROM codes WHERE used_by IS NOT NULL")
        users.extend(c.fetchall())
        conn.close()
    except Exception as e:
        print(f"[ERROR] get_all_active_users: {e}")
    return users