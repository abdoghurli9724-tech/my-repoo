# admin_control/renewival_engine.py
import sqlite3
from datetime import datetime, timedelta
from telebot import TeleBot

def renew_user_subscription(bot: TeleBot, admin_chat_id, user_id, code_type, renewal_option, custom_days=0):
    db_file = 'VIP_CODE_LOG.db' if code_type == 'vip' else 'NORMAL_CODE_LOG.db'
    
    try:
        conn = sqlite3.connect(db_file)
        c = conn.cursor()
        c.execute("SELECT expires_at FROM codes WHERE used_by = ?", (user_id,))
        row = c.fetchone()
        if not row:
            bot.send_message(admin_chat_id, "❌ لم يُعثر على كود لهذا المستخدم.")
            return False

        current_expires = datetime.fromisoformat(row[0])
        now = datetime.now()
        
        # إذا كان الكود منتهيًا، نبدأ من الآن
        base_time = max(current_expires, now)
        
        if renewal_option == "days":
            new_expires = base_time + timedelta(days=custom_days)
        elif renewal_option == "1":
            new_expires = base_time + timedelta(days=1)
        elif renewal_option == "7":
            new_expires = base_time + timedelta(days=7)
        elif renewal_option == "30":
            new_expires = base_time + timedelta(days=30)
        else:
            return False

        c.execute("UPDATE codes SET expires_at = ? WHERE used_by = ?", (new_expires.isoformat(), user_id))
        conn.commit()
        conn.close()

        # إرسال إشعار للمستخدم
        try:
            bot.send_message(user_id, "🎉 تم تجديد اشتراكك بنجاح!\n\nنشكرك على ثقتك بخدماتنا! 🙏")
        except:
            pass  # إذا لم يتمكن من إرسال رسالة (المستخدم لم يبدأ محادثة)

        bot.send_message(admin_chat_id, f"✅ تم تجديد اشتراك المستخدم {user_id} بنجاح حتى {new_expires.strftime('%Y-%m-%d')}.")
        return True

    except Exception as e:
        bot.send_message(admin_chat_id, f"❌ خطأ أثناء التجديد: {str(e)}")
        return False