# admin_control/trail_monitor.py
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
from trial_system.db_manager import get_all_trial_users
from datetime import datetime, timedelta

def show_trial_users(bot, chat_id):
    users = get_all_trial_users()
    if not users:
        bot.send_message(chat_id, "❌ لا يوجد مستخدمين تجريبيين نشطين.")
        return

    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    for user_id, activated_at in users:
        activated = datetime.fromisoformat(activated_at)
        expires = activated + timedelta(hours=24)
        remaining = expires - datetime.now()
        hours_left = int(remaining.total_seconds() // 3600)
        mins_left = int((remaining.total_seconds() % 3600) // 60)
        label = f"🆔 {user_id} | {hours_left}س {mins_left}د"
        markup.row(KeyboardButton(label))
    
    markup.row(KeyboardButton("🔙 العودة إلى CODE"))
    bot.send_message(chat_id, "المستخدمون التجريبيون النشطون:", reply_markup=markup)