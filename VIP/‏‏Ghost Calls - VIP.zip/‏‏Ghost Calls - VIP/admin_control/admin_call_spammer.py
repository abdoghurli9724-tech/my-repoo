# admin_control/admin_call_spammer.py
from features.call_spammer import send_single_call
import time
import threading

def start_admin_spam_flow(bot, chat_id):
    from telebot.types import ReplyKeyboardMarkup, KeyboardButton
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("العراق 🇮🇶"))
    markup.row(KeyboardButton("سوريا 🇸🇾"))
    markup.row(KeyboardButton("مصر 🇪🇬"))
    markup.row(KeyboardButton("⬅️ رجوع"))  # ← الزر الجديد
    bot.send_message(chat_id, "اختر الدولة:", reply_markup=markup)

def handle_admin_country(bot, chat_id, country_code):
    bot.send_message(chat_id, "أدخل الرقم المحلي:")
    bot.register_next_step_handler_by_chat_id(chat_id, lambda msg: _process_admin_phone(msg, bot, country_code))

def _process_admin_phone(message, bot, country_code):
    text = message.text.strip()
    if text == "⬅️ رجوع":
        from keyboards.admin_kb import get_admin_keyboard
        bot.send_message(message.chat.id, "✅ عدنا إلى لوحة المشرف.", reply_markup=get_admin_keyboard())
        return

    phone = text
    if not phone.isdigit():
        bot.send_message(message.chat.id, "❌ أدخل رقمًا صحيحًا:")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _process_admin_phone(msg, bot, country_code))
        return

    bot.send_message(message.chat.id, "أدخل عدد المحاولات:")
    bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _process_admin_count(msg, bot, country_code, phone))

def _process_admin_count(message, bot, country_code, phone):
    try:
        count = int(message.text.strip())
        if count < 1:
            raise ValueError
    except:
        bot.send_message(message.chat.id, "❌ أدخل عددًا صحيحًا:")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _process_admin_count(msg, bot, country_code, phone))
        return

    thread = threading.Thread(target=_send_admin_sequence, args=(bot, message.chat.id, country_code, phone, count))
    thread.start()

def _send_admin_sequence(bot, chat_id, country_code, phone, count):
    bot.send_message(chat_id, f"🎯 المشرف يبدأ إرسال {count} مكالمات...")

    for i in range(1, count + 1):
        if i > 1:
            bot.send_message(chat_id, f"⏳ انتظر 26 ثانية (المكالمة {i})...")
            time.sleep(26)  # ← التأخير المطلوب للمشرف

        success = send_single_call(country_code, phone)
        if success:
            bot.send_message(chat_id, f"✅ المكالمة {i}/{count} ناجحة!")
        else:
            bot.send_message(chat_id, f"❌ المكالمة {i}/{count} فاشلة.")

    bot.send_message(chat_id, "🔚 اكتمل الإرسال للمشرف.")