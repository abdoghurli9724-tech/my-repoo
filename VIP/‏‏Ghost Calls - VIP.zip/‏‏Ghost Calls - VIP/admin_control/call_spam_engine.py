# admin_control/call_spam_engine.py
import time
from features.call_spammer import send_call_attempt

def execute_spam_sequence(bot, chat_id, country_code, number, repeat_count):
    bot.send_message(chat_id, f"📞 بدء سبام المكالمات إلى {country_code}{number} (عدد المحاولات: {repeat_count})...")

    for i in range(1, repeat_count + 1):
        if i > 1:
            bot.send_message(chat_id, f"⏳ انتظر 26 ثانية قبل المحاولة التالية ({i-1}/{repeat_count})...")
            time.sleep(26)

        bot.send_message(chat_id, f"🔄 جاري إرسال المحاولة {i}/{repeat_count}...")

        success = send_call_attempt(country_code, number)

        if success:
            bot.send_message(chat_id, f"✅ نجاح: تم إرسال المحاولة {i} بنجاح!")
        else:
            bot.send_message(chat_id, f"❌ فشل: لم تُرسل المحاولة {i}.")

    bot.send_message(chat_id, "🔚 اكتملت جميع المحاولات!")