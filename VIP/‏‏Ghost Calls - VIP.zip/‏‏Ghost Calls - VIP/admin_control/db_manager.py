# admin_control/db_manager.py
import sqlite3
from datetime import datetime, timedelta

def init_databases():
    """إنشاء أو تحديث جداول الأكواد لضمان وجود جميع الأعمدة المطلوبة."""
    _init_normal_db()
    _init_vip_db()

def _init_normal_db():
    conn = sqlite3.connect('NORMAL_CODE_LOG.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            days INTEGER NOT NULL,
            hours INTEGER NOT NULL,
            minutes INTEGER NOT NULL,
            admin_id INTEGER NOT NULL,
            used_by INTEGER,          -- ID المستخدم الذي استخدم الكود
            used_at TEXT              -- وقت استخدام الكود
        )
    ''')
    conn.commit()
    conn.close()

def _init_vip_db():
    conn = sqlite3.connect('VIP_CODE_LOG.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            days INTEGER NOT NULL,
            hours INTEGER NOT NULL,
            minutes INTEGER NOT NULL,
            admin_id INTEGER NOT NULL,
            used_by INTEGER,          -- ID المستخدم الذي استخدم الكود
            used_at TEXT              -- وقت استخدام الكود
        )
    ''')
    conn.commit()
    conn.close()

def save_normal_code(code, days, hours, minutes, admin_id):
    created = datetime.now()
    expires = created + timedelta(days=days, hours=hours, minutes=minutes)
    conn = sqlite3.connect('NORMAL_CODE_LOG.db')
    c = conn.cursor()
    c.execute('''
        INSERT INTO codes (code, created_at, expires_at, days, hours, minutes, admin_id)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (code, created.isoformat(), expires.isoformat(), days, hours, minutes, admin_id))
    conn.commit()
    conn.close()

def save_vip_code(code, days, hours, minutes, admin_id):
    created = datetime.now()
    expires = created + timedelta(days=days, hours=hours, minutes=minutes)
    conn = sqlite3.connect('VIP_CODE_LOG.db')
    c = conn.cursor()
    c.execute('''
        INSERT INTO codes (code, created_at, expires_at, days, hours, minutes, admin_id)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (code, created.isoformat(), expires.isoformat(), days, hours, minutes, admin_id))
    conn.commit()
    conn.close()