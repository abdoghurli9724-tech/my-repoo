# admin_control/code_manager.py
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
from .renew_subscription.ui import show_user_selection

def get_code_control_keyboard():
    """لوحة التحكم الفرعية لميزة CODE (بدون وظائف بعد)."""
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("Create New Code"))
    markup.row(KeyboardButton("Renew subscription"))
    markup.row(KeyboardButton("Control All Code"))
    markup.row(KeyboardButton("Trail"))
    markup.row(KeyboardButton("🔙 العودة للوحة الرئيسية"))
    return markup

def show_code_control_panel(bot, chat_id):
    bot.send_message(
        chat_id,
        "🛡️ *إدارة الأكواد*\nاختر إحدى الخيارات:",
        reply_markup=get_code_control_keyboard(),
        parse_mode="Markdown"
    )