# admin_control/call_spam/state_manager.py
# تخزين مؤقت لحالة كل مشرف (يمكن استبداله بـ DB لاحقًا)
user_states = {}

def set_user_state(user_id, key, value):
    if user_id not in user_states:
        user_states[user_id] = {}
    user_states[user_id][key] = value

def get_user_state(user_id, key, default=None):
    return user_states.get(user_id, {}).get(key, default)

def clear_user_state(user_id):
    if user_id in user_states:
        del user_states[user_id]