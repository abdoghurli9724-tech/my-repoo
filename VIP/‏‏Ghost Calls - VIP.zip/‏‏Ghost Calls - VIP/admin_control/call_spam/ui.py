# admin_control/call_spam/ui.py
from telebot.types import ReplyKeyboardMarkup, KeyboardButton

def get_country_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("العراق 🇮🇶"))
    markup.row(KeyboardButton("سوريا 🇸🇾"))
    markup.row(KeyboardButton("مصر 🇪🇬"))
    markup.row(KeyboardButton("🔙 إلغاء"))
    return markup

def show_country_selection(bot, chat_id):
    bot.send_message(
        chat_id,
        "✅ لديك عدد غير محدود من المحاولات كمشرف.\n\n"
        "اختر الدولة المستهدفة:",
        reply_markup=get_country_keyboard()
    )