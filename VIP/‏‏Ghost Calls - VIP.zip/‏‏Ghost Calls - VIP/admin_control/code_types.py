# admin_control/code_types.py
from telebot.types import ReplyKeyboardMarkup, KeyboardButton

def get_code_type_keyboard():
    """لوحة اختيار نوع الكود: NORMAL / VIP"""
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("NORMAL"))
    markup.row(KeyboardButton("VIP"))
    markup.row(KeyboardButton("🔙 العودة إلى CODE"))
    return markup

def show_code_type_panel(bot, chat_id):
    """عرض لوحة اختيار نوع الكود."""
    bot.send_message(
        chat_id,
        "🎯 اختر نوع الكود المراد إنشاؤه:",
        reply_markup=get_code_type_keyboard()
    )