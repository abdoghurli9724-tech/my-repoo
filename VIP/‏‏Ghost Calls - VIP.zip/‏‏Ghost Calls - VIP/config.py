# config.py
BOT_TOKEN = "8503783303:AAGuu-YSzPlxaWsyet3NeOQ1L7d9KP2cOJw"  # <<< ضع توكن بوتك هنا
ADMIN_IDS = {8432769336}  # <<< ضع معرّفات التيليجرام للمشرفين هنا (أرقام فقط)