# user_system/call_spammer_vip.py
from features.call_spammer import send_single_call
from user_system.db_user_codes import get_user_daily_usage, update_user_daily_usage
import time
import threading

DAILY_LIMIT_VIP = 150

def start_vip_flow(bot, chat_id, user_id):
    from telebot.types import ReplyKeyboardMarkup, KeyboardButton
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("العراق 🇮🇶"))
    markup.row(KeyboardButton("سوريا 🇸🇾"))
    markup.row(KeyboardButton("مصر 🇪🇬"))
    markup.row(KeyboardButton("⬅️ رجوع"))  # ← الزر الجديد
    bot.send_message(chat_id, "اختر الدولة:", reply_markup=markup)

def handle_vip_country(bot, chat_id, user_id, country_code):
    used, _ = get_user_daily_usage(user_id, "vip")
    remaining = DAILY_LIMIT_VIP - used
    if remaining <= 0:
        bot.send_message(chat_id, f"❌ استهلكت جميع محاولاتك اليوم ({DAILY_LIMIT_VIP}/150).")
        return

    bot.send_message(chat_id, f"لديك {remaining} محاولة متبقية. أدخل الرقم:")
    bot.register_next_step_handler_by_chat_id(chat_id, lambda msg: _process_vip_number(msg, bot, user_id, country_code, remaining))

def _process_vip_number(message, bot, user_id, country_code, remaining):
    text = message.text.strip()
    if text == "⬅️ رجوع":  # ← تحقق من زر الرجوع أولًا
        from keyboards.vip_user_kb import get_vip_user_keyboard
        bot.send_message(message.chat.id, "✅ عدنا إلى لوحة أدوات VIP.", reply_markup=get_vip_user_keyboard())
        return

    phone = text
    if not phone.isdigit():
        bot.send_message(message.chat.id, "❌ أدخل رقمًا صحيحًا:")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _process_vip_number(msg, bot, user_id, country_code, remaining))
        return

    bot.send_message(message.chat.id, f"أدخل عدد المحاولات (1–{remaining}):")
    bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _process_vip_count(msg, bot, user_id, country_code, phone, remaining))

def _process_vip_count(message, bot, user_id, country_code, phone, remaining):
    try:
        count = int(message.text.strip())
        if count < 1 or count > remaining:
            raise ValueError
    except:
        bot.send_message(message.chat.id, f"❌ أدخل عددًا بين 1 و {remaining}:")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _process_vip_count(msg, bot, user_id, country_code, phone, remaining))
        return

    thread = threading.Thread(target=_send_vip_sequence, args=(bot, message.chat.id, user_id, country_code, phone, count))
    thread.start()

def _send_vip_sequence(bot, chat_id, user_id, country_code, phone, count):
    bot.send_message(chat_id, f"🚀 بدء إرسال {count} مكالمات...")

    for i in range(1, count + 1):
        if i > 1:
            bot.send_message(chat_id, f"⏳ انتظر 26 ثانية قبل المحاولة {i}...")
            time.sleep(26)

        success = send_single_call(country_code, phone)
        if success:
            bot.send_message(chat_id, f"✅ المحاولة {i}/{count} ناجحة!")
        else:
            bot.send_message(chat_id, f"❌ المحاولة {i}/{count} فاشلة.")

    update_user_daily_usage(user_id, "vip", count)
    used, _ = get_user_daily_usage(user_id, "vip")
    remaining = DAILY_LIMIT_VIP - used
    bot.send_message(chat_id, f"🔚 اكتمل الإرسال. المحاولات المتبقية: {remaining}/150")