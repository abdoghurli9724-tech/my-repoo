# user_system/user_status.py
import sqlite3
from datetime import datetime

def is_code_valid(code, code_type):
    """التحقق من صحة الكود (وجوده + عدم انتهائه)"""
    db_file = 'NORMAL_CODE_LOG.db' if code_type == 'normal' else 'VIP_CODE_LOG.db'
    try:
        conn = sqlite3.connect(db_file)
        c = conn.cursor()
        c.execute("SELECT expires_at FROM codes WHERE code = ?", (code,))
        row = c.fetchone()
        conn.close()
        if not row:
            return False
        expires_at = datetime.fromisoformat(row[0])
        return datetime.now() < expires_at
    except:
        return False

def is_code_already_used(code, code_type):
    """التحقق مما إذا كان الكود مستخدمًا مسبقًا (حتى لو انتهت صلاحيته)"""
    db_file = 'NORMAL_CODE_LOG.db' if code_type == 'normal' else 'VIP_CODE_LOG.db'
    try:
        conn = sqlite3.connect(db_file)
        c = conn.cursor()
        c.execute("SELECT used_by FROM codes WHERE code = ?", (code,))
        row = c.fetchone()
        conn.close()
        return row and row[0] is not None
    except:
        return False

def mark_code_as_used(code, code_type, user_id):
    """تسجيل أن الكود تم استخدامه من قبل هذا المستخدم"""
    db_file = 'NORMAL_CODE_LOG.db' if code_type == 'normal' else 'VIP_CODE_LOG.db'
    try:
        conn = sqlite3.connect(db_file)
        c = conn.cursor()
        c.execute("UPDATE codes SET used_by = ?, used_at = ? WHERE code = ?", 
                  (user_id, datetime.now().isoformat(), code))
        conn.commit()
        conn.close()
        return True
    except:
        return False

def get_code_type(code):
    """تحديد نوع الكود من شكله"""
    if code.startswith("N-"):
        return "normal"
    elif code.startswith("@CoderStormVip"):
        return "vip"
    return None