# user_system/db_user_codes.py (محدّث)
import sqlite3
from datetime import datetime, date

def init_user_db():
    conn = sqlite3.connect('user_codes.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS user_codes (
            user_id INTEGER PRIMARY KEY,
            code TEXT NOT NULL,
            code_type TEXT NOT NULL,
            activated_at TEXT NOT NULL
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS daily_usage (
            user_id INTEGER PRIMARY KEY,
            usage_date TEXT NOT NULL,
            normal_used INTEGER DEFAULT 0,
            vip_used INTEGER DEFAULT 0
        )
    ''')
    conn.commit()
    conn.close()

def save_user_code(user_id, code, code_type):
    conn = sqlite3.connect('user_codes.db')
    c = conn.cursor()
    c.execute('''
        INSERT OR REPLACE INTO user_codes (user_id, code, code_type, activated_at)
        VALUES (?, ?, ?, ?)
    ''', (user_id, code, code_type, datetime.now().isoformat()))
    conn.commit()
    conn.close()

def get_user_code_info(user_id):
    conn = sqlite3.connect('user_codes.db')
    c = conn.cursor()
    c.execute("SELECT code, code_type FROM user_codes WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    conn.close()
    return row

def remove_user_code(user_id):
    conn = sqlite3.connect('user_codes.db')
    c = conn.cursor()
    c.execute("DELETE FROM user_codes WHERE user_id = ?", (user_id,))
    c.execute("DELETE FROM daily_usage WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()

def get_user_daily_usage(user_id, code_type):
    today = date.today().isoformat()
    conn = sqlite3.connect('user_codes.db')
    c = conn.cursor()
    c.execute("SELECT usage_date, normal_used, vip_used FROM daily_usage WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    
    if not row or row[0] != today:
        # إعادة التعيين اليومي
        c.execute('''
            INSERT OR REPLACE INTO daily_usage (user_id, usage_date, normal_used, vip_used)
            VALUES (?, ?, ?, ?)
        ''', (user_id, today, 0, 0))
        conn.commit()
        conn.close()
        return (0, today)
    
    normal_used, vip_used = row[1], row[2]
    conn.close()
    return (normal_used if code_type == "normal" else vip_used, today)

def update_user_daily_usage(user_id, code_type, amount=1):
    today = date.today().isoformat()
    conn = sqlite3.connect('user_codes.db')
    c = conn.cursor()
    if code_type == "normal":
        c.execute("UPDATE daily_usage SET normal_used = normal_used + ? WHERE user_id = ? AND usage_date = ?", (amount, user_id, today))
    else:
        c.execute("UPDATE daily_usage SET vip_used = vip_used + ? WHERE user_id = ? AND usage_date = ?", (amount, user_id, today))
    conn.commit()
    conn.close()