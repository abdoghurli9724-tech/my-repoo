# user_system/call_spammer_normal.py
from features.call_spammer import send_single_call
from user_system.db_user_codes import get_user_daily_usage, update_user_daily_usage
import threading

DAILY_LIMIT_NORMAL = 10

def start_normal_flow(bot, chat_id, user_id):
    from telebot.types import ReplyKeyboardMarkup, KeyboardButton
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("العراق 🇮🇶"))
    markup.row(KeyboardButton("سوريا 🇸🇾"))
    markup.row(KeyboardButton("مصر 🇪🇬"))
    markup.row(KeyboardButton("⬅️ رجوع"))  # ← الزر الجديد
    bot.send_message(chat_id, "اختر الدولة:", reply_markup=markup)

def handle_normal_country(bot, chat_id, user_id, country_code):
    used, _ = get_user_daily_usage(user_id, "normal")
    remaining = DAILY_LIMIT_NORMAL - used
    if remaining <= 0:
        bot.send_message(chat_id, f"❌ استهلكت جميع محاولاتك اليوم ({DAILY_LIMIT_NORMAL}/10).")
        return

    bot.send_message(chat_id, f"لديك {remaining} محاولة متبقية. أدخل الرقم:")
    bot.register_next_step_handler_by_chat_id(chat_id, lambda msg: _process_normal_number(msg, bot, user_id, country_code))

def _process_normal_number(message, bot, user_id, country_code):
    text = message.text.strip()
    if text == "⬅️ رجوع":  # ← تحقق من زر الرجوع أولًا
        from keyboards.normal_user_kb import get_normal_user_keyboard
        bot.send_message(message.chat.id, "✅ عدنا إلى لوحة الأدوات.", reply_markup=get_normal_user_keyboard())
        return

    phone = text
    if not phone.isdigit():
        bot.send_message(message.chat.id, "❌ أدخل رقمًا صحيحًا:")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _process_normal_number(msg, bot, user_id, country_code))
        return

    # إرسال مكالمة واحدة فقط
    thread = threading.Thread(target=_send_normal_call, args=(bot, message.chat.id, user_id, country_code, phone))
    thread.start()

def _send_normal_call(bot, chat_id, user_id, country_code, phone):
    bot.send_message(chat_id, "📞 جاري إرسال المكالمة...")
    success = send_single_call(country_code, phone)

    if success:
        update_user_daily_usage(user_id, "normal", 1)
        used, _ = get_user_daily_usage(user_id, "normal")
        remaining = DAILY_LIMIT_NORMAL - used
        bot.send_message(chat_id, f"✅ نجاح! محاولاتك المتبقية: {remaining}/10")
    else:
        bot.send_message(chat_id, "❌ فشل في الإرسال.")