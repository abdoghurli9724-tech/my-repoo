# trial_system/trial_handler.py
from .db_manager import add_trial_user, is_trial_active, remove_expired_trial

def activate_trial_for_new_user(user_id):
    """تفعيل التجربة عند أول دخول"""
    add_trial_user(user_id)

def check_and_cleanup_trial(bot, user_id, chat_id):
    """
    التحقق من انتهاء التجربة عند كل /start.
    إذا انتهت → إرسال رسالة + الحذف.
    """
    if not is_trial_active(user_id):
        # حذف من القاعدة
        remove_expired_trial(user_id)
        # إرسال رسالة احترافية
        bot.send_message(
            chat_id,
            "⏳ انتهت الفترة التجريبية.\n\n"
            "للاستمرار، يمكنك التواصل مع المطور للحصول على اشتراك دائم.\n"
            "أو اكتب /start لرؤية تفاصيل البوت."
        )
        return False
    return True