# trial_system/call_spammer_trial.py
from features.call_spammer import send_single_call
from trial_system.db_manager import is_trial_active
import time
import threading

DAILY_LIMIT_TRIAL = 300  # 300 محاولة في اليوم
TIME_DELAY = 26  # 26 ثانية بين كل محاولة

def start_trial_flow(bot, chat_id, user_id):
    if not is_trial_active(user_id):
        bot.send_message(chat_id, "❌ انتهت تجربتك التجريبية.")
        return

    from telebot.types import ReplyKeyboardMarkup, KeyboardButton
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.row(KeyboardButton("العراق 🇮🇶"))
    markup.row(KeyboardButton("سوريا 🇸🇾"))
    markup.row(KeyboardButton("مصر 🇪🇬"))
    markup.row(KeyboardButton("⬅️ رجوع"))
    bot.send_message(chat_id, "اختر الدولة:", reply_markup=markup)

def handle_trial_country(bot, chat_id, user_id, country_code):
    if not is_trial_active(user_id):
        bot.send_message(chat_id, "❌ انتهت تجربتك التجريبية.")
        return

    bot.send_message(chat_id, "أدخل الرقم المحلي:")
    bot.register_next_step_handler_by_chat_id(chat_id, lambda msg: _process_trial_phone(msg, bot, user_id, country_code))

def _process_trial_phone(message, bot, user_id, country_code):
    if message.text.strip() == "⬅️ رجوع":
        from keyboards.trial_user_kb import get_trial_user_keyboard
        bot.send_message(message.chat.id, "✅ عدنا إلى لوحة التجربة.", reply_markup=get_trial_user_keyboard())
        return

    phone = message.text.strip()
    if not phone.isdigit():
        bot.send_message(message.chat.id, "❌ أدخل رقمًا صحيحًا:")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _process_trial_phone(msg, bot, user_id, country_code))
        return

    bot.send_message(message.chat.id, f"أدخل عدد المحاولات (حتى 300):")
    bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _process_trial_count(msg, bot, user_id, country_code, phone))

def _process_trial_count(message, bot, user_id, country_code, phone):
    if message.text.strip() == "⬅️ رجوع":
        from keyboards.trial_user_kb import get_trial_user_keyboard
        bot.send_message(message.chat.id, "✅ عدنا إلى لوحة التجربة.", reply_markup=get_trial_user_keyboard())
        return

    try:
        count = int(message.text.strip())
        if count < 1 or count > DAILY_LIMIT_TRIAL:
            raise ValueError
    except:
        bot.send_message(message.chat.id, f"❌ أدخل عددًا بين 1 و {DAILY_LIMIT_TRIAL}:")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _process_trial_count(msg, bot, user_id, country_code, phone))
        return

    thread = threading.Thread(target=_send_trial_sequence, args=(bot, message.chat.id, user_id, country_code, phone, count))
    thread.start()

def _send_trial_sequence(bot, chat_id, user_id, country_code, phone, count):
    from trial_system.db_manager import is_trial_active
    if not is_trial_active(user_id):
        bot.send_message(chat_id, "❌ انتهت تجربتك أثناء التنفيذ.")
        return

    bot.send_message(chat_id, f"✨ بدء إرسال {count} مكالمة (تجريبي)...")

    for i in range(1, count + 1):
        if i > 1:
            bot.send_message(chat_id, f"⏳ انتظر {TIME_DELAY} ثانية (المحاولة {i})...")
            time.sleep(TIME_DELAY)

        if not is_trial_active(user_id):
            bot.send_message(chat_id, "❌ انتهت تجربتك — تم إيقاف الإرسال.")
            break

        success = send_single_call(country_code, phone)
        if success:
            bot.send_message(chat_id, f"✅ المحاولة {i}/{count} ناجحة!")
        else:
            bot.send_message(chat_id, f"❌ المحاولة {i}/{count} فاشلة.")

    bot.send_message(chat_id, "🔚 اكتمل الإرسال التجريبي.")