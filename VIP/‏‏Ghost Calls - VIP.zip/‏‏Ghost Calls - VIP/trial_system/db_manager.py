# trial_system/db_manager.py
import sqlite3
from datetime import datetime

def init_trial_db():
    """إنشاء قاعدة بيانات التجربة إذا لم تكن موجودة"""
    conn = sqlite3.connect('TRAIL_24.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS trial_users (
            user_id INTEGER PRIMARY KEY,
            activated_at TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def add_trial_user(user_id):
    """إضافة مستخدم جديد للتجربة"""
    from datetime import datetime
    conn = sqlite3.connect('TRAIL_24.db')
    c = conn.cursor()
    c.execute(
        "INSERT OR IGNORE INTO trial_users (user_id, activated_at) VALUES (?, ?)",
        (user_id, datetime.now().isoformat())
    )
    conn.commit()
    conn.close()

def is_trial_active(user_id):
    """التحقق مما إذا كانت التجربة لا تزال سارية (أقل من 24 ساعة)"""
    from datetime import datetime, timedelta
    conn = sqlite3.connect('TRAIL_24.db')
    c = conn.cursor()
    c.execute("SELECT activated_at FROM trial_users WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    conn.close()
    if not row:
        return False
    activated = datetime.fromisoformat(row[0])
    return datetime.now() < activated + timedelta(hours=24)

def remove_expired_trial(user_id):
    """حذف المستخدم من قاعدة التجربة"""
    conn = sqlite3.connect('TRAIL_24.db')
    c = conn.cursor()
    c.execute("DELETE FROM trial_users WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()

def get_all_trial_users():
    """للمشرف: جلب جميع المستخدمين التجريبيين النشطين"""
    from datetime import datetime, timedelta
    conn = sqlite3.connect('TRAIL_24.db')
    c = conn.cursor()
    c.execute("SELECT user_id, activated_at FROM trial_users")
    rows = c.fetchall()
    conn.close()
    
    active_users = []
    now = datetime.now()
    for user_id, activated_at in rows:
        activated = datetime.fromisoformat(activated_at)
        if now < activated + timedelta(hours=24):
            active_users.append((user_id, activated_at))
    return active_users