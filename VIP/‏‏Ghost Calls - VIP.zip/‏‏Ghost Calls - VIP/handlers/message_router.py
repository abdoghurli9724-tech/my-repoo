# handlers/message_router.py
from telebot import TeleBot
from features.user_info import send_bot_info
from config import ADMIN_IDS
from user_system.db_user_codes import get_user_code_info

def register(bot: TeleBot):
    """تسجيل معالج جميع الرسائل النصية."""
    bot.register_message_handler(handle_user_message, func=lambda msg: True, pass_bot=True)

# --- دوال مساعدة ---
def _process_new_code(message, bot):
    from features.code_activation import handle_code_activation
    handle_code_activation(bot, message, is_new_code=True)

def _handle_renewal_choice(message, bot, user_id, code_type):
    text = message.text.strip()
    
    # عند الضغط على "إلغاء" من لوحة مدة التمديد → العودة إلى اختيار ID
    if text == "🔙 إلغاء":
        from admin_control.renew_subscription.ui import show_user_selection
        show_user_selection(bot, message.chat.id)
        return

    from admin_control.renew_subscription.renewal_engine import renew_user_subscription
    success = False

    if text == "+1 يوم":
        success = renew_user_subscription(bot, message.chat.id, user_id, code_type, "1")
    elif text == "+7 أيام":
        success = renew_user_subscription(bot, message.chat.id, user_id, code_type, "7")
    elif text == "+30 يومًا":
        success = renew_user_subscription(bot, message.chat.id, user_id, code_type, "30")
    elif text == "تحديد وقت مخصص":
        bot.send_message(message.chat.id, "أدخل عدد الأيام المطلوبة (مثال: 15):")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _handle_custom_days(msg, bot, user_id, code_type))
        return
    else:
        bot.send_message(message.chat.id, "❌ خيار غير معروف.")
        return

    if not success:
        bot.send_message(message.chat.id, "❌ فشل في تجديد الاشتراك.")

def _handle_custom_days(message, bot, user_id, code_type):
    text = message.text.strip()
    
    # التحقق من زر الإلغاء أولًا
    if text == "🔙 إلغاء":
        from admin_control.code_manager import show_code_control_panel
        show_code_control_panel(bot, message.chat.id)
        return

    try:
        days = int(text)
        if days < 1 or days > 365:
            raise ValueError("خارج النطاق")
        
        from admin_control.renew_subscription.renewal_engine import renew_user_subscription
        success = renew_user_subscription(bot, message.chat.id, user_id, code_type, "days", custom_days=days)
        
        if not success:
            bot.send_message(message.chat.id, "❌ فشل في تجديد الاشتراك.")
            
    except (ValueError, TypeError):
        bot.send_message(message.chat.id, "❌ أدخل عدد أيام صحيح (بين 1 و 365):")
        bot.register_next_step_handler_by_chat_id(message.chat.id, lambda msg: _handle_custom_days(msg, bot, user_id, code_type))

# --- معالج الرسائل الأساسي ---
def handle_user_message(message, bot: TeleBot):
    text = message.text.strip()
    chat_id = message.chat.id
    user_id = message.from_user.id

    # === أزرار المستخدم العادي ===
    if text == "ℹ️ معلومات البوت":
        send_bot_info(bot, chat_id)

    elif text == "✨ ميزات متاحة":
        bot.send_message(
            chat_id,
            "🌟 *الميزات المتاحة لك:*\n\n"
            "• عرض معلومات البوت\n"
            "• طلب دعم فني\n"
            "• التواصل مع المطور\n\n"
            "🔒 الميزات المتقدمة متاحة فقط للمشرفين.",
            parse_mode="Markdown"
        )

    elif text == "📥 طلب دعم":
        bot.send_message(chat_id, "✍️ يُرجى كتابة طلبك أو سؤالك، وسنتواصل معك قريبًا.")

    elif text == "👨‍💻 المطور":
        bot.send_message(chat_id, "للتواصل مع المطور: [@CoderStormVip](https://t.me/@CoderStormVip)", parse_mode="Markdown")

    elif text == "CODE":
        if user_id in ADMIN_IDS:
            from admin_control.code_manager import show_code_control_panel
            show_code_control_panel(bot, chat_id)
        else:
            from features.code_feature import handle_code_feature
            handle_code_feature(bot, chat_id)

    # === أزرار المشرف ===
    elif text == "📞 تشغيل سبام المكالمات":
        if user_id in ADMIN_IDS:
            from admin_control.admin_call_spammer import start_admin_spam_flow
            start_admin_spam_flow(bot, chat_id)
        else:
            bot.send_message(chat_id, "❌ ليس لديك صلاحية.")

    elif text == "⚙️ لوحة التحكم":
        if user_id in ADMIN_IDS:
            from admin_control.code_manager import show_code_control_panel
            show_code_control_panel(bot, chat_id)
        else:
            bot.send_message(chat_id, "❌ صلاحية غير كافية.")

    # === لوحة التحكم الفرعية: CODE ===
    elif text == "Create New Code":
        if user_id in ADMIN_IDS:
            from admin_control.code_types import show_code_type_panel
            show_code_type_panel(bot, chat_id)
        else:
            bot.send_message(chat_id, "❌ صلاحية غير كافية.")

    elif text == "🔙 العودة إلى CODE":
        if user_id in ADMIN_IDS:
            from admin_control.code_manager import show_code_control_panel
            show_code_control_panel(bot, chat_id)
        else:
            bot.send_message(chat_id, "❌ صلاحية غير كافية.")

    elif text == "NORMAL":
        if user_id in ADMIN_IDS:
            from admin_control.create_normal_code import handle_normal_code
            handle_normal_code(bot, chat_id, user_id)
        else:
            bot.send_message(chat_id, "❌ صلاحية غير كافية.")

    elif text == "VIP":
        if user_id in ADMIN_IDS:
            from admin_control.create_vip_code import handle_vip_code
            handle_vip_code(bot, chat_id, user_id)
        else:
            bot.send_message(chat_id, "❌ صلاحية غير كافية.")

    # === أزرار المستخدم بعد التفعيل ===
    elif text == "NEW CODE":
        user_info = get_user_code_info(user_id)
        if user_info:
            bot.send_message(chat_id, "🔑 أدخل كود تفعيل جديد:")
            bot.register_next_step_handler_by_chat_id(chat_id, lambda msg: _process_new_code(msg, bot))
        else:
            bot.send_message(chat_id, "يجب تفعيل كود أولاً.")

    elif text == "📞 سبام مكالمات (عادي)":
        user_info = get_user_code_info(user_id)
        if user_info and user_info[1] == "normal":
            from user_system.call_spammer_normal import start_normal_flow
            start_normal_flow(bot, chat_id, user_id)
        else:
            bot.send_message(chat_id, "❌ فعّل كود عادي أولاً.")

    elif text == "📞 سبام مكالمات (VIP)":
        user_info = get_user_code_info(user_id)
        if user_info and user_info[1] == "vip":
            from user_system.call_spammer_vip import start_vip_flow
            start_vip_flow(bot, chat_id, user_id)
        else:
            bot.send_message(chat_id, "❌ هذه الميزة لمستخدمي VIP فقط.")

    # === اختيار الدولة (مشترك لجميع الأدوار) ===
    elif text in ["العراق 🇮🇶", "سوريا 🇸🇾", "مصر 🇪🇬"]:
        country_map = {"العراق 🇮🇶": "+964", "سوريا 🇸🇾": "+963", "مصر 🇪🇬": "+20"}
        country_code = country_map[text]
        user_info = get_user_code_info(user_id)

        if user_id in ADMIN_IDS:
            from admin_control.admin_call_spammer import handle_admin_country
            handle_admin_country(bot, chat_id, country_code)
        elif user_info and user_info[1] == "normal":
            from user_system.call_spammer_normal import handle_normal_country
            handle_normal_country(bot, chat_id, user_id, country_code)
        elif user_info and user_info[1] == "vip":
            from user_system.call_spammer_vip import handle_vip_country
            handle_vip_country(bot, chat_id, user_id, country_code)
        else:
            bot.send_message(chat_id, "❌ صلاحية غير كافية.")

    elif text == "⬅️ رجوع":
        user_id = message.from_user.id
        user_info = get_user_code_info(user_id)

        if user_id in ADMIN_IDS:
            from keyboards.admin_kb import get_admin_keyboard
            bot.send_message(chat_id, "✅ عدنا إلى لوحة المشرف.", reply_markup=get_admin_keyboard())
        elif user_info and user_info[1] == "normal":
            from keyboards.normal_user_kb import get_normal_user_keyboard
            bot.send_message(chat_id, "✅ عدنا إلى لوحة الأدوات.", reply_markup=get_normal_user_keyboard())
        elif user_info and user_info[1] == "vip":
            from keyboards.vip_user_kb import get_vip_user_keyboard
            bot.send_message(chat_id, "✅ عدنا إلى لوحة أدوات VIP.", reply_markup=get_vip_user_keyboard())
        else:
            from keyboards.user_kb import get_user_keyboard
            bot.send_message(chat_id, "✅ عدنا إلى القائمة الرئيسية.", reply_markup=get_user_keyboard())

    # --- معالجة Renew subscription ---
    elif text == "Renew subscription":
        if user_id in ADMIN_IDS:
            from admin_control.renew_subscription.ui import show_user_selection
            show_user_selection(bot, chat_id)
        else:
            bot.send_message(chat_id, "❌ صلاحية غير كافية.")

    # --- اختيار مستخدم من القائمة ---
    elif "🆔 " in text and " | " in text and user_id in ADMIN_IDS:
        try:
            user_id_selected = int(text.split("🆔 ")[1].split(" |")[0])
            from admin_control.renew_subscription.user_fetcher import get_all_active_users
            users = get_all_active_users()
            user_data = None
            for uid, code, code_type, expires_at in users:
                if uid == user_id_selected:
                    user_data = (uid, code_type, expires_at)
                    break
            if user_data:
                from admin_control.renew_subscription.ui import show_renewal_options
                show_renewal_options(bot, chat_id, user_data[0], user_data[1], user_data[2])
                # تخزين الحالة مؤقتًا (باستخدام ذاكرة بسيطة)
                bot.register_next_step_handler_by_chat_id(chat_id, lambda msg: _handle_renewal_choice(msg, bot, user_data[0], user_data[1]))
            else:
                bot.send_message(chat_id, "❌ المستخدم غير موجود في القائمة.")
        except:
            bot.send_message(chat_id, "❌ خطأ في اختيار المستخدم.")

    # --- معالجة اختيار مدة التجديد ---
    elif text in ["+1 يوم", "+7 أيام", "+30 يومًا", "تحديد وقت مخصص"] and user_id in ADMIN_IDS:
        # سيتم التعامل معها عبر register_next_step_handler
        pass

    elif text == "Trail":
        if user_id in ADMIN_IDS:
            from admin_control.trail_monitor import show_trial_users
            show_trial_users(bot, chat_id)
        else:
            bot.send_message(chat_id, "❌ صلاحية غير كافية.")

    elif "🆔 " in text and " | " in text and "س " in text and user_id in ADMIN_IDS:
        try:
            user_id_selected = int(text.split("🆔 ")[1].split(" |")[0])
            from trial_system.db_manager import get_all_trial_users
            users = get_all_trial_users()
            for uid, activated_at in users:
                if uid == user_id_selected:
                    from datetime import datetime, timedelta
                    activated = datetime.fromisoformat(activated_at)
                    expires = activated + timedelta(hours=24)
                    remaining = expires - datetime.now()
                    hours = int(remaining.total_seconds() // 3600)
                    mins = int((remaining.total_seconds() % 3600) // 60)
                    bot.send_message(chat_id, f"⏱️ المستخدم {user_id_selected}\nالوقت المتبقي: {hours} ساعة و {mins} دقيقة.")
                    return
            bot.send_message(chat_id, "❌ المستخدم غير نشط حاليًّا.")
        except:
            bot.send_message(chat_id, "❌ خطأ في المعالجة.")

    # === رسائل غير معروفة ===
    else:
        pass  # يمكن إضافة مساعدة هنا لاحقًا
