# handlers/start_handler.py
from telebot import TeleBot
from config import ADMIN_IDS
from user_system.db_user_codes import get_user_code_info
from user_system.user_status import is_code_valid
from keyboards import user_kb, normal_user_kb, vip_user_kb

def register(bot: TeleBot):
    bot.register_message_handler(start_command, commands=["start"], pass_bot=True)

def start_command(message, bot: TeleBot):
    user_id = message.from_user.id
    chat_id = message.chat.id

    # تحقق مما إذا كان المشرف
    if user_id in ADMIN_IDS:
        from keyboards.admin_kb import get_admin_keyboard
        bot.send_message(chat_id, "مرحباً يا مشرف! 🛡️", reply_markup=get_admin_keyboard())
        return

    # تحقق من حالة المستخدم العادي
    user_info = get_user_code_info(user_id)
    if user_info:
        code, code_type = user_info
        # تحقق مما إذا كان الكود ما زال صالحًا
        from user_system.user_status import is_code_valid
        if is_code_valid(code, code_type):
            if code_type == "normal":
                bot.send_message(chat_id, "مرحباً بك! 🔄", reply_markup=normal_user_kb.get_normal_user_keyboard())
            else:
                bot.send_message(chat_id, "مرحباً بك يا مستخدم VIP! 💎", reply_markup=vip_user_kb.get_vip_user_keyboard())
            return
        else:
            # الكود منتهي أو غير صالح → إزالته
            from user_system.db_user_codes import remove_user_code
            remove_user_code(user_id)

    # لوحة المستخدم الأساسية
    bot.send_message(chat_id, "مرحباً بك! 👋", reply_markup=user_kb.get_user_keyboard())